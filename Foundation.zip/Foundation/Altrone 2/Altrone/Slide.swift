//
//  Slide.swift
//  Altrone
//
//  Created by Evan Tanuwijaya on 04/07/19.
//  Copyright © 2019 Evan Tanuwijaya. All rights reserved.
//

import UIKit

class Slide: UIView {

    @IBOutlet weak var ImageSlide: UIImageView!
    @IBOutlet weak var TitleSlide: UILabel!
    @IBOutlet weak var DescSlide: UILabel!
    
    
}
